v1 = input("Enter #1: ")
v2 = input("Enter #2: ")

v1 = float(v1)
v2 = int(v2)

print(v1 + v2)  # merged together || sum
print(v1 * v2)  # error           || product

v3 = hex(v2)
v4 = bin(v2)
v5 = oct(v2)
