"""
Each character in a string
has a numerical value

ASCII table
charts numerical value to
their character values

"""

letter_b = chr(98)
print(letter_b)
letter_B = chr(66)
print(letter_B)

num_val_z = ord("z")
print(num_val_z)