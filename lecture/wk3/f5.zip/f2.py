import math

print("2^3 =", 2**3)  # 8
v1 = abs(-34214)  # non-negative value


v2 = math.floor(123.456)  # 123

v3 = math.ceil(567.89)  # 568

v4 = 5 // 2  # 2 iso 2.5
v5 = 5/2  # 2.5

v6 = 10
v6 += 1  # 11

v6 %= 2  # 1