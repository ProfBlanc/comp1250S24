name = input("Enter your name")
age = int(input("Enter your age"))

print(name == "Ben" and age >= 100)
