print("e" in "Ben")  # True

print("50" in "comp1250")  # True

print("h" in "Hello")  # False

print("h" in "Hello".swapcase().title())  #
#            hELLO
#            HELLO

courseCode = "comp1250"
print(courseCode[0])  # 'c'

print(courseCode[5]) # 2

print(courseCode[5].isdigit())  # True

print(2 in courseCode)  #