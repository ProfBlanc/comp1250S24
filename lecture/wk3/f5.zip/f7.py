"""
user inputted credentials
match a database entrie
"""
username = input("Enter your username: ")
password = input("Enter your password: ")

print("admin" in username and "pass" in password)

"""
if <boolean expresson>:
    statements to run if ^ True
elif <boolean expression>:
    statemetns to run if ^ True
else:
"""